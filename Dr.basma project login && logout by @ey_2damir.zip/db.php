<?php
$servername = "localhost";
$username = "root"; // ضع هنا اسم المستخدم الخاص بقاعدة البيانات
$password = ""; // ضع هنا كلمة المرور الخاصة بقاعدة البيانات
$dbname = "student_management"; // اسم قاعدة البيانات

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}
?>
